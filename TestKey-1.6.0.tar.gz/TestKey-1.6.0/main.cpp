#include <iostream>
#include <iomanip>
#include <map>
#include <unordered_map>
 
#include <key.h>
#include <pubkey.h>
#include <keystore.h>
#include <uint256.h>
#include <script/standard.h>
#include <script/script.h>
#include <script/ismine.h>
#include <base58.h>
#include <netaddress.h>
#include <protocol.h>
#include <base58.h>
#include <chainparams.h>
#include <utilstrencodings.h>

#include <core_io.h>
#include <consensus/validation.h>
#include <fs.h>
#include <sync.h>
#include <random.h>
#include <utiltime.h>
#include <utilmoneystr.h>
#include <util.h>
#include <chain.h>
#include <streams.h>
#include <clientversion.h>
#include <consensus/merkle.h>
#include <wallet/walletutil.h>
#include <addrdb.h>
#include <addrman.h>

#include <boost/algorithm/string/replace.hpp>
#include <boost/algorithm/string/join.hpp>
#include <boost/thread.hpp>

// 打印n个x字符
void print_line(int n, char x)
{
	std::cout<<std::endl<<std::setw(n);
	std::cout<<std::setfill(x)<<" "<<std::endl;
}

// 打印容器
template<typename T1>
void print_vector(const T1 pos, int size)
{
	unsigned char *begin = (unsigned char*)&pos[0];
	for(int ii = 0; ii < size; ii++) {
		std::cout<<std::setw(2);
		std::cout<<std::setfill('0')<<std::hex<<(int)(*(begin + ii));
	}
	print_line(20, '-');
}

/**
 * 测试密钥对
 * 私钥：9a9a6539856be209b8ea2adbd155c0919646d108515b60b7b13d6a79f1ae5174
 * 公钥：0340a609475afa1f9a784cad0db5d5ba7dbaab2147a5d7b9bbde4d1334a0e40a5e
 */
std::vector<unsigned char> TestPriKey = {
	0x9a, 0x9a, 0x65, 0x39, 0x85, 0x6b, 0xe2, 0x09,
	0xb8, 0xea, 0x2a, 0xdb, 0xd1, 0x55, 0xc0, 0x91,
	0x96, 0x46, 0xd1, 0x08, 0x51, 0x5b, 0x60, 0xb7,
	0xb1, 0x3d, 0x6a, 0x79, 0xf1, 0xae, 0x51, 0x74
};
std::vector<unsigned char> TestPubKey = {0x03,
                                         0x40, 0xa6, 0x09, 0x47, 0x5a, 0xfa, 0x1f, 0x9a,
                                         0x78, 0x4c, 0xad, 0x0d, 0xb5, 0xd5, 0xba, 0x7d,
                                         0xba, 0xab, 0x21, 0x47, 0xa5, 0xd7, 0xb9, 0xbb,
                                         0xde, 0x4d, 0x13, 0x34, 0xa0, 0xe4, 0x0a, 0x5e
                                        };
/**
 * Alice:
 * PriKey: 6bce49ff84094382d822178de357a435f85e8ad8fdfa39bd58aa2e5192267198
 * PubKey: 03e3bd2f408e4415aa57c747f6550937823a8605706c358facdc6325b4a99f2161
 */
std::vector<unsigned char> TestPriKeyA = {
	0x6b, 0xce, 0x49, 0xff, 0x84, 0x09, 0x43, 0x82,
	0xd8, 0x22, 0x17, 0x8d, 0xe3, 0x57, 0xa4, 0x35,
	0xf8, 0x5e, 0x8a, 0xd8, 0xfd, 0xfa, 0x39, 0xbd,
	0x58, 0xaa, 0x2e, 0x51, 0x92, 0x26, 0x71, 0x98
};
std::vector<unsigned char> TestPubKeyA = {0x03,
                                          0xe3, 0xbd, 0x2f, 0x40, 0x8e, 0x44, 0x15, 0xaa,
                                          0x57, 0xc7, 0x47, 0xf6, 0x55, 0x09, 0x37, 0x82,
                                          0x3a, 0x86, 0x05, 0x70, 0x6c, 0x35, 0x8f, 0xac,
                                          0xdc, 0x63, 0x25, 0xb4, 0xa9, 0x9f, 0x21, 0x61
                                         };
/**
 * Bob:
 * PriKey: 3e46c724c8e9728379a9cab2ec46030563f06d7e0ace2b734b5861b8f64b6f2f
 * PubKey: 020e80933a750e84b4c35c10bc797ca34d1c885e4e65531a7499170a1c78ffdd97
 */
std::vector<unsigned char> TestPriKeyB = {
	0x3e, 0x46, 0xc7, 0x24, 0xc8, 0xe9, 0x72, 0x83,
	0x79, 0xa9, 0xca, 0xb2, 0xec, 0x46, 0x03, 0x05,
	0x63, 0xf0, 0x6d, 0x7e, 0x0a, 0xce, 0x2b, 0x73,
	0x4b, 0x58, 0x61, 0xb8, 0xf6, 0x4b, 0x6f, 0x2f
};
std::vector<unsigned char> TestPubKeyB = {0x02,
                                          0x0e, 0x80, 0x93, 0x3a, 0x75, 0x0e, 0x84, 0xb4,
                                          0xc3, 0x5c, 0x10, 0xbc, 0x79, 0x7c, 0xa3, 0x4d,
                                          0x1c, 0x88, 0x5e, 0x4e, 0x65, 0x53, 0x1a, 0x74,
                                          0x99, 0x17, 0x0a, 0x1c, 0x78, 0xff, 0xdd, 0x97
                                         };
/**
 * Martin:
 * PriKey: bfe5647b87c61058969bbe599879c49372fa0d6e2bfc71125960e3c1de5fbc0b
 * PubKey: 039155f9024807d126be4df4d09273c5fece4767e89b4527c68b48414a2877eddd
 */
std::vector<unsigned char> TestPriKeyM = {
	0xbf, 0xe5, 0x64, 0x7b, 0x87, 0xc6, 0x10, 0x58,
	0x96, 0x9b, 0xbe, 0x59, 0x98, 0x79, 0xc4, 0x93,
	0x72, 0xfa, 0x0d, 0x6e, 0x2b, 0xfc, 0x71, 0x12,
	0x59, 0x60, 0xe3, 0xc1, 0xde, 0x5f, 0xbc, 0x0b
};
std::vector<unsigned char> TestPubKeyM = {0x03,
                                          0x91, 0x55, 0xf9, 0x02, 0x48, 0x07, 0xd1, 0x26,
                                          0xbe, 0x4d, 0xf4, 0xd0, 0x92, 0x73, 0xc5, 0xfe,
                                          0xce, 0x47, 0x67, 0xe8, 0x9b, 0x45, 0x27, 0xc6,
                                          0x8b, 0x48, 0x41, 0x4a, 0x28, 0x77, 0xed, 0xdd
                                         };

/**
 * Debug tansaction hex
 */
std::string TestHexTx = "02000000000101991816e3bd6bb9faf77b836560f01d433d4819dbb3499120a3"\
                        "704c69b4d73f4200000000232200206f0f2d495c106ccb69b10a8f57ca115674"\
                        "d0f302fa918b29df65e464b132c18dffffffff0158a007000000000017a9147c"\
                        "7020ed135a05c86bcec1c491426eec48efb2a9870400483045022100cf5d6620"\
                        "11e226a82d8cb860290565acfe42cd332a16d2c4c81a60fa01b3c37802201983"\
                        "bd20263889acc18c06a47ee36cf77c6594fd1b0ddf8f9d20b954071bda170147"\
                        "304402205637494e4efbe71052d084f133c81f6af7d134170f12b546c3ca926f"\
                        "f80bbff9022037bffc1e9cba1c485032d5fc6cf92f73d8fe76295c467ff48b0b"\
                        "9cdcfe2a52010169522103e3bd2f408e4415aa57c747f6550937823a8605706c"\
                        "358facdc6325b4a99f216121020e80933a750e84b4c35c10bc797ca34d1c885e"\
                        "4e65531a7499170a1c78ffdd9721039155f9024807d126be4df4d09273c5fece"\
                        "4767e89b4527c68b48414a2877eddd53ae00000000";
std::string TestHexTx2 = "0200000000010176345c521e457a604000b1543aaa6bcdfef274bb614662f363"\
                         "c3b63ba0d6f1f300000000171600148e0d7aae920edda41e3fd0ae89fe0f8460"\
                         "c3132ffdffffff0220a107000000000017a914910eb5b15177193bad6bf65216"\
                         "a969289aca0ba1877aa007000000000017a914f1e97dd31778893c6f31a94f83"\
                         "ea7cb9b5340498870247304402202aa82440092153d4a316c31048f5e794a7ba"\
                         "96b2b217d77610127fca2661981e0220515d4d189918a889cb4c90aac71603a7"\
                         "c3f108f806ab2e41c23a5ca65c9c0ee7012103e3bd2f408e4415aa57c747f655"\
                         "0937823a8605706c358facdc6325b4a99f2161247d1500";

/**
 * Test Block Hash
 */

uint256 TestBlkHash = uint256S("0x00000000000001a9055c41e6f0c4d86c66ba5e3fae87c38f5281cf48bf5b1e82");
/**
 * Test Transaction Hash
 */
uint256 TestTxHash = uint256S("0x67fcaf25ee12ee132ce6bbe179d064777a2e81e749fb51e103fd19e438337080");

/**
 * Test block disk position
 */
CDiskBlockPos TestBlockPos(129,38418855);

// Main
int main(int argc, char** argv)
{
	
	/** Peers List */
	print_line(100, '=');
	std::cout<<"Peers List Test";
	print_line(100, '=');
	// 设置为测试网络 
	SelectParams(CBaseChainParams::TESTNET);
	// 设置数据存储目录 
	gArgs.SoftSetArg("-datadir","../Bitcoin");
	const CChainParams& chainparams = Params();
	// Check data path
	std::cout<<"**** Data Path: "<<GetDataDir()<<std::endl;
	print_line(100, '=');
	CAddrDB addrdb;

	// Read peers.dat
	CAddrMan addr;
	if(addrdb.Read(addr)){
		// Get address
		std::vector<CAddress> cAddresses = addr.GetAddr();
		// Show ips 
		for(int ii = 0; ii < cAddresses.size() && ii < 16; ii ++){
			std::cout << ii << " : " << cAddresses[ii].ToString() << std::endl;
		}
	}
	print_line(100, '=');
	return 0;
}
