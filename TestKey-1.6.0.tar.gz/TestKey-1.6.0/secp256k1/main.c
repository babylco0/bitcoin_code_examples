#include "include/secp256k1.h"
#include <stdio.h>

int main(int argc, char *argv[]){
	printf("Test.\n");
	return 0;
}
